/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/vhdl2019w/YYI2015117185/ALU2015117185/test_ArithmeticUnit_mod.vhd";
extern char *IEEE_P_1242562249;
extern char *IEEE_P_2592010699;

char *ieee_p_1242562249_sub_1547198987_1035706684(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_1919365254_1035706684(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_1919437128_1035706684(char *, char *, char *, char *, int );
char *ieee_p_2592010699_sub_1837678034_503743352(char *, char *, char *, char *);


static void work_a_1574583891_3212880686_p_0(char *t0)
{
    char t14[16];
    char t20[16];
    char *t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    unsigned char t12;
    unsigned char t13;
    char *t15;
    char *t16;
    char *t17;
    unsigned int t18;
    unsigned int t19;
    char *t21;

LAB0:    xsi_set_current_line(46, ng0);
    t1 = (t0 + 960U);
    t2 = *((char **)t1);
    t1 = (t0 + 3563);
    t4 = 1;
    if (2U == 2U)
        goto LAB5;

LAB6:    t4 = 0;

LAB7:    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 960U);
    t2 = *((char **)t1);
    t1 = (t0 + 3565);
    t4 = 1;
    if (2U == 2U)
        goto LAB13;

LAB14:    t4 = 0;

LAB15:    if (t4 != 0)
        goto LAB11;

LAB12:    t1 = (t0 + 960U);
    t2 = *((char **)t1);
    t1 = (t0 + 3567);
    t4 = 1;
    if (2U == 2U)
        goto LAB24;

LAB25:    t4 = 0;

LAB26:    if (t4 != 0)
        goto LAB22;

LAB23:    xsi_set_current_line(68, ng0);
    t1 = xsi_get_transient_memory(8U);
    memset(t1, 0, 8U);
    t2 = t1;
    memset(t2, (unsigned char)1, 8U);
    t3 = (t0 + 1132U);
    t6 = *((char **)t3);
    t3 = (t6 + 0);
    memcpy(t3, t1, 8U);
    xsi_set_current_line(69, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 3448U);
    t3 = ieee_p_1242562249_sub_1919437128_1035706684(IEEE_P_1242562249, t14, t2, t1, 1);
    t6 = (t0 + 1928);
    t7 = (t6 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t3, 8U);
    xsi_driver_first_trans_fast_port(t6);

LAB3:    t1 = (t0 + 1884);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(47, ng0);
    t8 = xsi_get_transient_memory(8U);
    memset(t8, 0, 8U);
    t9 = t8;
    memset(t9, (unsigned char)1, 8U);
    t10 = (t0 + 1132U);
    t11 = *((char **)t10);
    t10 = (t11 + 0);
    memcpy(t10, t8, 8U);
    xsi_set_current_line(48, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 1928);
    t3 = (t1 + 32U);
    t6 = *((char **)t3);
    t7 = (t6 + 40U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 8U);
    xsi_driver_first_trans_fast_port(t1);
    goto LAB3;

LAB5:    t5 = 0;

LAB8:    if (t5 < 2U)
        goto LAB9;
    else
        goto LAB7;

LAB9:    t6 = (t2 + t5);
    t7 = (t1 + t5);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB6;

LAB10:    t5 = (t5 + 1);
    goto LAB8;

LAB11:    xsi_set_current_line(51, ng0);
    t8 = (t0 + 776U);
    t9 = *((char **)t8);
    t12 = *((unsigned char *)t9);
    t13 = (t12 == (unsigned char)3);
    if (t13 != 0)
        goto LAB19;

LAB21:    xsi_set_current_line(54, ng0);
    t1 = (t0 + 684U);
    t2 = *((char **)t1);
    t1 = (t0 + 1132U);
    t3 = *((char **)t1);
    t1 = (t3 + 0);
    memcpy(t1, t2, 8U);

LAB20:    xsi_set_current_line(56, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 3448U);
    t3 = (t0 + 1132U);
    t6 = *((char **)t3);
    t3 = (t0 + 3512U);
    t7 = ieee_p_1242562249_sub_1547198987_1035706684(IEEE_P_1242562249, t14, t2, t1, t6, t3);
    t8 = (t0 + 1928);
    t9 = (t8 + 32U);
    t10 = *((char **)t9);
    t11 = (t10 + 40U);
    t15 = *((char **)t11);
    memcpy(t15, t7, 8U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB3;

LAB13:    t5 = 0;

LAB16:    if (t5 < 2U)
        goto LAB17;
    else
        goto LAB15;

LAB17:    t6 = (t2 + t5);
    t7 = (t1 + t5);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB14;

LAB18:    t5 = (t5 + 1);
    goto LAB16;

LAB19:    xsi_set_current_line(52, ng0);
    t8 = (t0 + 684U);
    t10 = *((char **)t8);
    t8 = (t0 + 3464U);
    t11 = ieee_p_1242562249_sub_1919365254_1035706684(IEEE_P_1242562249, t14, t10, t8, 1);
    t15 = (t0 + 1132U);
    t16 = *((char **)t15);
    t15 = (t16 + 0);
    t17 = (t14 + 12U);
    t18 = *((unsigned int *)t17);
    t19 = (1U * t18);
    memcpy(t15, t11, t19);
    goto LAB20;

LAB22:    xsi_set_current_line(59, ng0);
    t8 = (t0 + 776U);
    t9 = *((char **)t8);
    t12 = *((unsigned char *)t9);
    t13 = (t12 == (unsigned char)3);
    if (t13 != 0)
        goto LAB30;

LAB32:    xsi_set_current_line(63, ng0);
    t1 = (t0 + 684U);
    t2 = *((char **)t1);
    t1 = (t0 + 3464U);
    t3 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t14, t2, t1);
    t6 = (t0 + 1132U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    t8 = (t14 + 12U);
    t5 = *((unsigned int *)t8);
    t18 = (1U * t5);
    memcpy(t6, t3, t18);

LAB31:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 3448U);
    t3 = (t0 + 1132U);
    t6 = *((char **)t3);
    t3 = (t0 + 3512U);
    t7 = ieee_p_1242562249_sub_1547198987_1035706684(IEEE_P_1242562249, t14, t2, t1, t6, t3);
    t8 = (t0 + 1928);
    t9 = (t8 + 32U);
    t10 = *((char **)t9);
    t11 = (t10 + 40U);
    t15 = *((char **)t11);
    memcpy(t15, t7, 8U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB3;

LAB24:    t5 = 0;

LAB27:    if (t5 < 2U)
        goto LAB28;
    else
        goto LAB26;

LAB28:    t6 = (t2 + t5);
    t7 = (t1 + t5);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB25;

LAB29:    t5 = (t5 + 1);
    goto LAB27;

LAB30:    xsi_set_current_line(60, ng0);
    t8 = (t0 + 684U);
    t10 = *((char **)t8);
    t8 = (t0 + 3464U);
    t11 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t20, t10, t8);
    t15 = ieee_p_1242562249_sub_1919365254_1035706684(IEEE_P_1242562249, t14, t11, t20, 1);
    t16 = (t0 + 1132U);
    t17 = *((char **)t16);
    t16 = (t17 + 0);
    t21 = (t14 + 12U);
    t18 = *((unsigned int *)t21);
    t19 = (1U * t18);
    memcpy(t16, t15, t19);
    goto LAB31;

}


extern void work_a_1574583891_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1574583891_3212880686_p_0};
	xsi_register_didat("work_a_1574583891_3212880686", "isim/test_Arithmetic_Unit_tb_isim_beh.exe.sim/work/a_1574583891_3212880686.didat");
	xsi_register_executes(pe);
}
